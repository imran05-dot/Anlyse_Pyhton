import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from pandas import read_csv

# Configurer les options pandas
pd.set_option('display.width', 100)
pd.set_option('display.float_format', '{:.2f}'.format)

try:
    fichier = "BeansDataSet.csv"
    col = ['Channel_1', 'Region_1', 'Robusta_1', 'Arabica_1', 
           'Espresso_1', 'Lungo_1', 'Latte_1', 'Cappuccino_1']
    data = read_csv(fichier, names=col, skiprows=1)  
    patients = [f'Anne_{i}' for i in range(1, len(data) + 1)]  
    data.index = patients

    pd.set_option('display.width', 100)
    pd.set_option('display.float_format', '{:.2f}'.format)
    print(f'DataFrame \n----------\n {data}')
except FileNotFoundError:
    print("Erreur de lecture : fichier introuvable.")


# Titre et description
st.title("Analyse des Données - BeansDataSet")
st.write("Visualisation et analyse du jeu de données BeansDataSet.")


# Afficher les 5 premières lignes
if st.checkbox("Afficher les 5 premières lignes du dataset"):
    st.write(data.head())
# Afficher les 5 dernières lignes
if st.checkbox("Afficher les 5 dernières lignes du dataset"):
    st.write(data.tail())
# Dimensions du dataset
st.write(f"### Dimensions du dataset : {data.shape[0]} lignes et {data.shape[1]} colonnes")
# Types des colonnes
if st.checkbox("Afficher les types de colonnes"):
    st.write(data.dtypes)

# Vérifier les valeurs manquantes
if st.checkbox("Afficher les valeurs manquantes"):
    st.write("### Présence de valeurs manquantes par colonne")
    st.write(data.isnull().sum())
    fig, ax = plt.subplots()
    sns.heatmap(data.isnull(), cbar=False, cmap="plasma", ax=ax)
    st.pyplot(fig)

# Statistiques descriptives
if st.checkbox("Afficher les statistiques descriptives"):
    st.write("### Statistiques Descriptives")
    st.write(data.describe())

# Distribution des colonnes numériques
numeric_data = data.select_dtypes(include=['number'])
if st.checkbox("Afficher l'histogramme des colonnes numériques"):
    st.write("## Histogrammes")
    fig, axes = plt.subplots(len(numeric_data.columns), 1, figsize=(10, 5 * len(numeric_data.columns)))
    if len(numeric_data.columns) == 1:
        axes = [axes]  # Gérer un seul subplot
    for ax, col in zip(axes, numeric_data.columns):
        sns.histplot(data[col], kde=True, ax=ax)
        ax.set_title(f"Distribution de {col}")
    st.pyplot(fig)

# Matrice de corrélation
if st.checkbox("Afficher la matrice de corrélation"):
    st.write("## Matrice de Corrélation")
    fig, ax = plt.subplots(figsize=(10, 8))
    sns.heatmap(numeric_data.corr(), annot=True, cmap="coolwarm", fmt=".2f", ax=ax)
    st.pyplot(fig)

# Boîte à moustaches
if st.checkbox("Afficher les boîtes à moustaches des colonnes numériques"):
    st.write("### Boîtes à Moustaches")
    fig, axes = plt.subplots(len(numeric_data.columns), 1, figsize=(10, 5 * len(numeric_data.columns)))
    if len(numeric_data.columns) == 1:
        axes = [axes]
    for ax, col in zip(axes, numeric_data.columns):
        sns.boxplot(y=data[col], ax=ax)
        ax.set_title(f"Boîte à moustaches de {col}")
    st.pyplot(fig)

# Matrice de dispersion
if st.checkbox("Afficher les scatter plots (matrice de dispersion)"):
    st.write("### Matrice de Dispersion")
    try:
        hue_col = st.selectbox("Choisir une colonne pour la catégorisation", [None] + list(data.columns))
        if hue_col:
            fig = sns.pairplot(data, hue=hue_col)
        else:
            fig = sns.pairplot(data)
        st.pyplot(fig)
    except ValueError:
        st.warning("Aucune donnée valide pour tracer la matrice de dispersion.")

# Filtrer par colonne
if st.checkbox("Filtrer par valeurs spécifiques"):
    filter_col = st.selectbox("Choisissez une colonne pour filtrer", data.columns)
    unique_vals = data[filter_col].dropna().unique()
    selected_val = st.selectbox("Choisissez une valeur", unique_vals)
    filtered_data = data[data[filter_col] == selected_val]
    st.write(f"### Données filtrées ({filter_col} = {selected_val})")
    st.write(filtered_data)


# Ajouter un diagramme circulaire pour la dominance 
if st.checkbox("Afficher un graphique circulaire (camembert)"):
    st.subheader("Diagramme en camembert")
    column_for_pie = st.selectbox("Sélectionnez une colonne pour le diagramme circulaire", data.columns)
    if data[column_for_pie].nunique() <= 10:  # Limiter les colonnes ayant moins de 10 catégories
        pie_data = data[column_for_pie].value_counts() # Compter les occurrences
        # Création graphique circulaire
        fig, ax = plt.subplots()
        ax.pie(pie_data, labels=pie_data.index, autopct='%1.1f%%', startangle=90, colors=sns.color_palette("pastel"))
        ax.set_title(f"Répartition des catégories dans {column_for_pie}")
        st.pyplot(fig)
    else:
        st.warning("La colonne sélectionnée contient trop de catégories pour un graphique circulaire.")

